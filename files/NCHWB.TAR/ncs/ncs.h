#define ARRAYLEN   1000
#define MAXPACKETS 8*ARRAYLEN
#define MAXLENGTH  10000	/* max packet size */

struct Packet
    {
    int Uniquefier;
    int SeqNo;
    /* junk bytes come here */
    }
    *PBuffer;	/* packet buffer */

#define MASK(packet) (1 << (7 - ((packet) % 8)))
#define SETBIT(array, packet)   (array[(packet)/8] |= MASK(packet))
#define TESTBIT(array, packet)  (array[packet/8] & MASK(packet))
#define CLEARBIT(array, packet) (array[packet/8] &= (0xff ^ MASK(packet)))



#define STOP -999	/* Start packet number is 0 */
#define SERVERPORT	10000	/* default server port */
#define CLIENTPORT	10001	/* default client port */
